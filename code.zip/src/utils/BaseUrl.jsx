// const BaseUrl = "http://localhost:5000/api";
const BaseUrl = "https://tms-backend-production-9497.up.railway.app/api";

export default BaseUrl;