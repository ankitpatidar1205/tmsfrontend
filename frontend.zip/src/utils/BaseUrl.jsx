// const BaseUrl = "http://localhost:5000/api";
const BaseUrl = "https://tsm-backend-production.up.railway.app/api";

export default BaseUrl;